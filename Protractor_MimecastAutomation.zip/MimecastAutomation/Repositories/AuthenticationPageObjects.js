/**
 * Created by U6018855 on 30/08/2016.
 */

function AuthenticationPageObjects(){

    this.UrlAuthenticationPage=function () {

        return 'https://login-alpha.mimecast.com/m/secure/login/?tkn=WVXYHQ7cA8nSKgxK0RS4nkdOIDqpeB5cYTr3ptKQOtRRUm0poN7PZ_cOXXqmu1ZSPxbDSpccdqyHcLr4Z0WYoUUaJR4MrVGHESpRXK3_Gyw#/login';

                
        
    }

        //.//*[@id='ng-app']/body/div[5]/div[3]/div[2]/div/ul/li[1]/a

    this.refresh=function () {
        return element(by.xpath("//*[@id='ng-app']/body/div[5]/div[3]/div[2]/div/ul/li[1]/a"));
    }

    this.listAuthentication=function () {
        return element(by.id('ctl00_mainPageContent_ddlAuthMethod'));
    }

    this.txtBoxPassword=function () {
        //return element(by.model('appCtrl.password'));
        return element(by.xpath("//*[@id='password']"));
    }


    this.password=function () {
        return 'Renjulina_2009';
    }

    this.invalidPassword=function () {
        return 'invalidpassword'  ;
    }

    this.buttonNext2=function () {
       return element(by.xpath(".//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/div[3]/button[2]"));
    }



    this.linkLoginAsDifferentuser= function () {
        return element(by.xpath(".//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/div[3]/button[2]"));
        //                           *[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/div[3]/button[2]  
    }

    //https://login-alpha.mimecast.com/m/secure/login/?tkn=WVXYHQ7cA8nSKgxK0RS4nkdOIDqpeB5cYTr3ptKQOtRRUm0poN7PZ_cOXXqmu1ZSPxbDSpccdqyHcLr4Z0WYoUUaJR4MrVGHESpRXK3_Gyw#/login

    this.invalidPasswordMessageBoxForInvalidUserName=function () {
        return element(by.xpath(".//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/div[3]/div/div"));
    }

    this.invalidPasswordMessageBoxForInvalidPassword=function () {
        return element(by.xpath(".//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/div[3]/div/div"));
                                  
    }





    this.forgotPasswordButton=function () {
        return element(by.xpath(".//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/div[3]/button[2]   "));


    }

    this.resetURL=function () {
        return 'https://login-alpha.mimecast.com/m/secure/login/?tkn=WVXYHQ7cA8nSKgxK0RS4nkdOIDqpeB5cYTr3ptKQOtRRUm0poN7PZ_cOXXqmu1ZSPxbDSpccdqyHcLr4Z0WYoUUaJR4MrVGHESpRXK3_Gyw#/forgot-password';
    }




    this.resetButton=function () {
        return element(by.xpath(".//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/button[1]"));
    }


    this.nevermindLink=function () {
        return element(by.xpath(".//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/div[2]/button"));
    }

    this.resetTextbox=function () {
        return element(by.model("forgotPasswordControllerCtrl.username"));
    }








};
module.exports=new AuthenticationPageObjects();
