/**
 * Created by U6018855 on 31/08/2016.
 */
function GeneralObjects(){

    this.GetPageTitle=function () {

        browser.getTitle();
    }

    this.GetPageURL=function () {

        browser.getUrl();
    }



};
module.exports=new GeneralObjects();

