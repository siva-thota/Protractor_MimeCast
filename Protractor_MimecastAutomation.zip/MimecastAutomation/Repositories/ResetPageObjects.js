/**
 * Created by U6018855 on 30/08/2016.
 */


function ResetPageObjects(){

    this.UrlResetPage=function () {

        return 'https://portal.mimecast.com/Partner/Account/Login.aspx';
    }










};
module.exports=new ResetPageObjects();
