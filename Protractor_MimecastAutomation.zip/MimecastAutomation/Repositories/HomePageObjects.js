/**
 * Created by U6018855 on 30/08/2016.
 */


function HomePageObjects(){

    this.UrlHomepage=function () {

        return 'https://login-alpha.mimecast.com/m/secure/login/?tkn=WVXYHQ7cA8nSKgxK0RS4nkdOIDqpeB5cYTr3ptKQOtRRUm0poN7PZ_cOXXqmu1ZSPxbDSpccdqyHcLr4Z0WYoUUaJR4MrVGHESpRXK3_Gyw#/login';
    }


    this.txtBoxLogin=function(){
        return element(by.model('appCtrl.username'));
    }
    this.userName=function () {

        return 'renju_k_m@hotmail.com';
        
    }
    this.buttonNext1=function () {
        return element(by.xpath("//*[@id='ng-app']/body/div[3]/div/div[2]/div/div/div[1]/div[1]/div/div/form/button[1]"));
        //return element(by.buttonText('Next'));
    }
    
    this.invalidUsername=function () {
        return 'invalid@test.com';
    }



};
module.exports=new HomePageObjects();
