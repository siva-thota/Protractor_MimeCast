/**
 * Created by U6018855 on 31/08/2016.
 */

var HomePageObjects= require('../../WDIO-Project/src/Repositories/HomePageObjects.js');
var AuthenticationPageObjects= require('../Repositories/AuthenticationPageObjects.js');
var ResetPageObjects= require('../Repositories/ResetPageObjects.js');
var GeneralObjects= require('../Repositories/GeneralObjects.js');


var AuthenticationPageFunctions=function () {



    //this.AuthenticationPresentIsenabled=function () {


        /*AuthenticationPageObjects.listAuthentication().isPresent().then(function (authenticationPresent) {

            if(authenticationPresent){

                console.log("Authentication   Present");

                AuthenticationPageObjects.listAuthentication().isEnabled().then(function (authenticationEnabled) {
                    if(authenticationEnabled){
                        console.log("Authentication  Enabled");
                    }else{
                        console.log("Authentication button NOT Enabled");
                    }
                });

            }else{
                console.log("Authentication button NOT Present");
            }

        });*/

   // };


    this.PasswordPresentIsenabled=function () {
        AuthenticationPageObjects.txtBoxPassword().isPresent().then(function (passwordPresent) {

            if(passwordPresent){
                console.log("Password box  Present");

                AuthenticationPageObjects.txtBoxPassword().isEnabled().then(function (passwordEnabled) {
                    if(passwordEnabled){
                        console.log("Password box  Enabled");
                    }else{
                        console.log("Password box  NOT Enabled");
                    }

                });

            }else{
                console.log("Password box NOT Present");

            }

        });

       //expect(browser.getUrl()).toEqual(AuthenticationPageObjects.UrlAuthenticationPage());

    }


    this.ClickLoginAsDifferentUserLink=function () {
        AuthenticationPageObjects.linkLoginAsDifferentuser().click();
        browser.sleep(2000);

        //expect(browser.getUrl()).toEqual(HomePageObjects.UrlHomepage());



    }




    this.InvalidUsernameLogin=function () {


        HomePageObjects.txtBoxLogin().sendKeys(HomePageObjects.invalidUsername());
        HomePageObjects.buttonNext1().click();
        AuthenticationPageObjects.txtBoxPassword().sendKeys(AuthenticationPageObjects.password());
        element(by.buttonText('Log In')).click();
        //AuthenticationPageObjects.buttonNext2().click();
       // browser.sleep(2000);

        AuthenticationPageObjects.invalidPasswordMessageBoxForInvalidUserName().isPresent().then(function (present) {

            if(present){
                AuthenticationPageObjects.invalidPasswordMessageBoxForInvalidUserName().getText().then(function (text) {
                    if(text){
                        console.log(text);
                        console.log("Invalid User name")
                        expect(AuthenticationPageObjects.invalidPasswordMessageBoxForInvalidUserName().getText()).toEqual('Username/Password is wrong or the account is locked out');
                    }

                });
            }else{

                console.log("Username Correct");

            }

        });

    }






    this.resetTexbox=function () {


        AuthenticationPageObjects.resetTextbox().isPresent().then(function (textboxpresent) {
            if(textboxpresent){
                console.log("Reset text box  Enabled");
            }else{
                console.log("Reset text box NOT Enabled");
            }

        });

    }



    this.resetButton=function () {


        AuthenticationPageObjects.resetButton().isPresent().then(function (resetbuttonPresent) {
            if(resetbuttonPresent){
                console.log("Reset button   Enabled");
            }else{
                console.log("Reset button  NOT Enabled");
            }

        });

    }


    this.neverMindtakemebacklink=function () {


        AuthenticationPageObjects.nevermindLink().isPresent().then(function (linkPresent) {
            if(linkPresent){
                console.log("Password box  Enabled");
            }else{
                console.log("Password box  NOT Enabled");
            }

        });

        AuthenticationPageObjects.nevermindLink().click();


        HomePageObjects.txtBoxLogin().isEnabled().then(function (loginEnabled) {

            if(loginEnabled){
                console.log("Email address element Enabled");
            }else{
                console.log("Email address element NOT enabled");
            }
        });

        AuthenticationPageObjects.txtBoxPassword().isEnabled().then(function (passwordEnabled) {
            if(passwordEnabled){
                console.log("Password box  Enabled");
            }else{
                console.log("Password box  NOT Enabled");
            }

        });




    }










    this.InvalidPasswordLogin=function () {



        HomePageObjects.txtBoxLogin().sendKeys(HomePageObjects.userName());
        HomePageObjects.buttonNext1().click();
        browser.sleep(2000);
        AuthenticationPageObjects.txtBoxPassword().sendKeys(AuthenticationPageObjects.invalidPassword());
        //element(by.buttonText('Log In').click());
        element(by.buttonText('Log In')).click();

        browser.sleep(2000);

        AuthenticationPageObjects.invalidPasswordMessageBoxForInvalidPassword().isPresent().then(function (presence) {
            if(presence){

                AuthenticationPageObjects.invalidPasswordMessageBoxForInvalidPassword().getText().then(function (text) {
                    console.log(text);
                    console.log("Invalid Password")
                    expect(AuthenticationPageObjects.invalidPasswordMessageBoxForInvalidPassword().getText()).toEqual('Username/Password is wrong or the account is locked out');

                });

            }else{

                console.log("Password Correct");

            }
        });




        }







    this.ValidLogin=function () {



        HomePageObjects.txtBoxLogin().sendKeys(HomePageObjects.userName());
        HomePageObjects.buttonNext1().click();
        browser.sleep(2000);
        AuthenticationPageObjects.txtBoxPassword().sendKeys(AuthenticationPageObjects.password());
        //element(by.buttonText('Log In').click());
        element(by.buttonText('Log In')).click();

        browser.sleep(2000);

        AuthenticationPageObjects.refresh().isPresent().then(function (presence) {
            if(presence){

                console.log("Login Successful");

                

            }else{

                console.log("Login unsuccessful");

            }




        });




    }



    this.sentEmail=function () {



        HomePageObjects.txtBoxLogin().sendKeys(HomePageObjects.userName());
        HomePageObjects.buttonNext1().click();
        browser.sleep(2000);
        AuthenticationPageObjects.txtBoxPassword().sendKeys(AuthenticationPageObjects.password());
        //element(by.buttonText('Log In').click());
        element(by.buttonText('Log In')).click();

        browser.sleep(2000);

        AuthenticationPageObjects.refresh().isPresent().then(function (presence) {
            if(presence){

                console.log("Login Successful");



            }else{

                console.log("Login unsuccessful");

            }


            element(by.xpath(".//*[@id='main-action']/button")).click();

            element(by.xpath("//*[@id='sendEmailForm']/div[1]/div[2]/div[1]/div[2]/div/div[1]/input")).sendKeys("sgarcia@mimecast.com");

            element(by.xpath(".//*[@id='sendEmailForm']/div[1]/div[2]/div[3]/div[2]/input")).sendKeys("Home Protractor Excercise");

            element(by.xpath(".//*[@id='sendEmailForm']/div[3]/div[2]/div[6]")).sendKeys("This is a test email from Renju regarding Protractor Home excercise, to check if it works.All the test cases are working individually. When run together  some errors are seen . Due to time factor could not look into  much detail..Sending the code via bitBucket soon Thanks Renju");
            browser.sleep(5000);


        });




    }







}



module.exports=new AuthenticationPageFunctions();