/**
 * Created by U6018855 on 31/08/2016.
 */

var HomePageObjects= require('../../WDIO-Project/src/Repositories/HomePageObjects.js');
var AuthenticationPageObjects= require('../Repositories/AuthenticationPageObjects.js');
var ResetPageObjects= require('../Repositories/ResetPageObjects.js');
var GeneralObjects= require('../Repositories/GeneralObjects.js');


var HomePageFunctions=function () {

    this.EmailPresenceIsenabled=function () {


                HomePageObjects.txtBoxLogin().isPresent().then(function (loginPresent) {
                    if(loginPresent){
                        console.log("Email Address element  Present");
                        HomePageObjects.txtBoxLogin().isEnabled().then(function (loginEnabled) {

                            if(loginEnabled){
                                console.log("Email address element Enabled");
                            }else{
                                console.log("Email address element NOT enabled");
                            }
                        });
                    }
                    else{
                        console.log("Email address element NOT Present");
                    }


                });


    };




    this.HomePageNextButtonPresenceCheckenabled=function () {

        HomePageObjects.buttonNext1().isPresent().then(function (nextPresent) {

            if(nextPresent){
                console.log("Next button Present");
                HomePageObjects.buttonNext1().isEnabled().then(function (nextEnabled) {
                    if(nextEnabled){
                        console.log("Next button Enabled");
                    }else {
                        console.log("Next button NOT Enabled");
                    }
                })


            }else{
                console.log("Next button NOT Present");
            }

        });

    };



};

module.exports=new HomePageFunctions();