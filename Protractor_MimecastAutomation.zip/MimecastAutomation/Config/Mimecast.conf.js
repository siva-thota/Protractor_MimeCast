//jshint strict: false
exports.config = {

  allScriptsTimeout: 11000,

  specs: [
    '../TestCases/Case6.js'
    
  ],

  capabilities: {
    'browserName': 'chrome'
  },

 // baseUrl: 'http://localhost:8000/',

  framework: 'jasmine',


  /*onComplete:function () {
console.log("Sending mail");
var sys=require('util')
    var exec=require('child_process').exec;

function puts(error,stdout,stderr) {sys.puts(stdout)}
    exec("node mail.js",puts);

  },*/

  jasmineNodeOpts: {
    defaultTimeoutInterval: 50000
  }




};
