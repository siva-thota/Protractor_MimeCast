/**
 * Created by U6018855 on 30/08/2016.
 */
var HomePageObjects= require('../../WDIO-Project/src/Repositories/HomePageObjects.js');
var AuthenticationPageObjects= require('../Repositories/AuthenticationPageObjects.js');
var ResetPageObjects= require('../Repositories/ResetPageObjects.js');
var GeneralObjects= require('../Repositories/GeneralObjects.js');
var AuthenticationPageFunctions=require('../Pages/AuthenticationPageFunctions.js');

describe("Mimecast Excercises", function () {

    it("Case5", function () {



        console.log("------------------------------------------------------");

        browser.get(HomePageObjects.UrlHomepage());


        AuthenticationPageFunctions.ValidLogin();
    });







});